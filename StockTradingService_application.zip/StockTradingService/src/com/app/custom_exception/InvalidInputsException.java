package com.app.custom_exception;

public class InvalidInputsException extends Exception {
	public InvalidInputsException(String msg) {
		super(msg);
	}
}
