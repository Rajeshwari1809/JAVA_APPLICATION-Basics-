package com.app.category;

public enum Category {
	cat,dog,rabbit,fish;
	
	//====================================
	
	private double price;

	private Category(double price) {
		this.price = price;
	}
	
	//====================================
	
	Category() {
	}

	public String toString()
	{
		return name()+" "+price;
	}
	
	//====================================
	
	public double getPrice()
	{
		return price;
	}
	
	

}
