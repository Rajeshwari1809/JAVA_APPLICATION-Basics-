package com.app.category;

public enum Status {
	placed,in_progress,completed,pending;

	private Status() {
	}
	
	//==================
	private String status;
	private Status(String status)
	{
		this.status=status;
	}
	
	//==================
	
	public String toString()
	{
		return name()+" "+status;
	}
	
	//==================
	
	public String getStatus()
	{
		return status;
	}

}
