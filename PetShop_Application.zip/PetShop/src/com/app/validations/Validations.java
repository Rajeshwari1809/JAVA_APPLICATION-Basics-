package com.app.validations;

import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.app.core.Pet;

public class Validations {
	
	public static Pet validateUsernamerpass()
	{
		String username="abc";
		String password="123";
		
		//validate username 
		
		Pattern usernameContent=Pattern.compile("^[A-Za-z]\\w{1,100}$");
		Matcher usernameMatcher=usernameContent.matcher(username);
		if(!usernameMatcher.matches())
		{
			System.out.println("invalid username");
			
		}
		
		Pattern passwordContent=Pattern.compile("^[0-9]");
		Matcher passwordMatcher=passwordContent.matcher(password);
		if(!passwordMatcher.matches())
		{
			System.out.println("invalid password");
		}
		
		
		System.out.println("register user successfully");
		
		
		return null;	
	}
	
	public static Pet updatePetDetails(Scanner sc,List<Pet>list)
	{
		System.out.println("enter the id which details you want to modify");
		String name=sc.next();
		for(Pet p: list)
		{
			if(p.getPetname().equals(name))
					{
				System.out.println("please update name ");
				p.setPetname(sc.next());
				p.setId(sc.nextInt());
				p.setStatus(sc.next());
				p.setStock(sc.nextInt());
				
					}
					
					
					
		}
		
		
		
		
		
		
		
		return null;
		
	}

}
