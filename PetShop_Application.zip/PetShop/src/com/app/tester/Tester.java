package com.app.tester;

import java.util.Scanner;

public class Tester {
	public static void main(String[]args)
	{
		try(Scanner sc=new Scanner(System.in))
		{
			boolean exit=false;
			while(!exit)
			{
				System.out.println("enter an option");
				System.out.println("1 :- ");
				System.out.println("2 :- ");
				System.out.println("3 :- ");
				System.out.println("4 :- ");
				System.out.println("choose an option ");
				try {
					switch(sc.nextInt())
					{
					case 1:
						break;
					case 2:
						break;
					case 3:
						break;
					case 4:
						break;
					case 5:
						break;
					case 6:
						break;
					
					
					}
				}catch (Exception e) {
					e.printStackTrace();
					System.out.println(e);
				}
			}
		}
		
	}

}
