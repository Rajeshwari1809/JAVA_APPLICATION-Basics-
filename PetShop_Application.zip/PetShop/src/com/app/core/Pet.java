package com.app.core;

import java.util.Objects;

import com.app.category.Category;
import com.app.category.Status;

public class Pet {
	private static int count=1;
	private int id;
	private Category category;
	private String petname;
	private int unitPrice;
	private int stock;
	private Status status;
	//-------------------------------------
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public int getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(int unitPrice) {
		this.unitPrice = unitPrice;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public String getPetname() {
		return petname;
	}
	public void setPetname(String petname) {
		this.petname = petname;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	//-------------------------------------
	public Pet(int id, Category category, int unitPrice, int stock, Status status) {
		super();
		this.id = ++count;
		this.category = category;
		this.unitPrice = unitPrice;
		this.stock = stock;
		this.status = status;
	}
	public Pet(int id2, String string, int unitPrice2, int stock2, String string2) {
		// TODO Auto-generated constructor stub
	}
	//---------------------------------------
	
	//----------------
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pet other = (Pet) obj;
		return id == other.id;
	}
	//=============================================
	@Override
	public String toString() {
		return "Pet [id=" + id + ", category=" + category + ", petname=" + petname + ", unitPrice=" + unitPrice
				+ ", stock=" + stock + ", status=" + status + "]";
	}
	
	

}
