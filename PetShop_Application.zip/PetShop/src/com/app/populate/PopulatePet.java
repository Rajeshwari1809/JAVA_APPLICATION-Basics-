package com.app.populate;

import java.util.ArrayList;

import com.app.category.Category;
import com.app.category.Status;
import com.app.core.Pet;

public class PopulatePet {
	
//	private int id;
//	private Category category;
//	private int unitPrice;
//	private int stock;
//	private Status status;
	
	public static ArrayList<Pet>populateList()
	{
		ArrayList<Pet>list=new ArrayList<>();
		list.add(new Pet(1,"cat",1000,10,"placed"));
		list.add(new Pet(2,"dog",3000,10,"placed"));
		list.add(new Pet(3,"fish",4000,10,"placed"));
		return list;
		
	}

}
