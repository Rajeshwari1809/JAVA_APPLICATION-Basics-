package com.app.exception;

public class Exceptionss extends Exception {
	
		public Exceptionss(String errMsg)
		{
			super(errMsg);
			
		}
	

}
